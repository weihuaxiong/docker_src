dockerfile.vim
==============

Syntax highlighting for Dockerfiles

Installation
------------

Via pathogen, the usual way...

Features
--------

The syntax highlighting includes:

* The directives (e.g. `FROM`)
* Strings
* Comments

License
-------

BSD, short and sweet
