package archive

const twBufSize = 32 * 1024
const trBufSize = 32 * 1024
