% DOCKER(1) Docker User Manuals
% Docker Community
% JUNE 2014
# NAME
docker-port - Lookup the public-facing port that is NAT-ed to PRIVATE_PORT

# SYNOPSIS
**docker port**
CONTAINER PRIVATE_PORT

# OPTIONS
There are no available options.

# HISTORY
April 2014, Originally compiled by William Henry (whenry at redhat dot com)
June 2014, updated by Sven Dowideit <SvenDowideit@home.org.au>
