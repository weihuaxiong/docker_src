var tipuesearch = {"pages": [
     {"title": "Tipue Search, a site search engine jQuery plugin", "text": "Tipue Search is a site search engine jQuery plugin. Tipue Search is open source and released under the MIT License, which means it's free for both commercial and non-commercial use. Tipue Search is responsive and works on all reasonably modern browsers.", "tags": "JavaScript", "loc": "http://www.tipue.com/search"},
     {"title": "Tipue Search Static mode demo", "text": "This is a demo of Tipue Search Static mode.", "tags": "", "loc": "http://www.tipue.com/search/demos/static"},
     {"title": "Tipue Image Search demo", "text": "This is a demo of Tipue Image Search.", "tags": "", "loc": "http://www.tipue.com/search/demos/images"},
     {"title": "Tipue Search docs", "text": "If you haven't already done so, download Tipue Search. Copy the tipuesearch folder to your site.", "tags": "documentation", "loc": "http://www.tipue.com/search/docs"},     
     {"title": "Tipue drop, a search suggestion box jQuery plugin", "text": "Tipue drop is a search suggestion box jQuery plugin. Tipue drop is open source and released under the MIT License, which means it's free for both commercial and non-commercial use. Tipue drop is responsive and works on all reasonably modern browsers.", "tags": "JavaScript", "loc": "http://www.tipue.com/drop"},
     {"title": "Tipue drop demo", "text": "Tipue drop demo. Tipue drop is a search suggestion box jQuery plugin.", "tags": "JavaScript", "loc": "http://www.tipue.com/drop/demo"},
     {"title": "Support plans", "text": "Stuck? We offer a range of flexible support plans for our jQuery plugins.", "tags": "", "loc": "http://www.tipue.com/support"},
     {"title": "About Tipue", "text": "Tipue is a small web development studio based in North London. We've been around for over a decade. We like Perl, MySQL and jQuery.", "tags": "", "loc": "http://www.tipue.com/about"}
]};



