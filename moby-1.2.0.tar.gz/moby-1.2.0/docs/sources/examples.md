# Examples

 - [Dockerizing a Node.js Web App](nodejs_web_app/)
 - [Dockerizing a Redis Service](running_redis_service/)
 - [Dockerizing an SSH Daemon Service](running_ssh_service/)
 - [Dockerizing a CouchDB Service](couchdb_data_volumes/)
 - [Dockerizing a PostgreSQL Service](postgresql_service/)
 - [Dockerizing MongoDB](mongodb/)
 - [Dockerizing a Riak Service](running_riak_service/)
